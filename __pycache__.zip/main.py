import sys
import sqlite3
from PyQt5.QtWidgets import QApplication, QDialog, QMessageBox
from PyQt5.QtGui import QIntValidator
from book_form_ui import Ui_Dialog  # or Ui_MainWindow (depends on your .ui)

class BookApp(QDialog):  # Use QMainWindow if you have a main window
    def __init__(self):
        super().__init__()
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)

        # Validator for quantity (integer only)
        self.ui.lineEdit_quantity.setValidator(QIntValidator(1, 9999, self))

        # Connect buttons
        self.ui.btn_find_price.clicked.connect(self.find_price)
        self.ui.btn_find_total.clicked.connect(self.find_total)

        # Connect to database
        self.conn = sqlite3.connect('books.db')
        self.cursor = self.conn.cursor()

    def find_price(self):
        title = self.ui.lineEdit_title.text().strip()
        if not title:
            QMessageBox.warning(self, "Input Error", "Enter a book title")
            return
        self.cursor.execute("SELECT price FROM books WHERE title = ?", (title,))
        result = self.cursor.fetchone()
        if result:
            self.ui.lineEdit_price.setText(str(result[0]))
        else:
            QMessageBox.warning(self, "Not Found", "Book not found")
            self.ui.lineEdit_price.clear()

    def find_total(self):
        price = self.ui.lineEdit_price.text()
        quantity = self.ui.lineEdit_quantity.text()
        if price and quantity:
            total = float(price) * int(quantity)
            self.ui.lineEdit_total.setText(str(round(total, 2)))
        else:
            QMessageBox.warning(self, "Calculation Error", "Enter price and quantity")

    def closeEvent(self, event):
        self.conn.close()
        event.accept()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = BookApp()
    window.show()
    sys.exit(app.exec_())
