import sqlite3

conn = sqlite3.connect('books.db')
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    author TEXT,
    price REAL
)
''')

books_data = [
    (1, 'python programming', 'john dey', 25.99),
    (2, 'data science basics', 'alice clark', 20.00),
    (3, 'ugly love', 'colleen hoover', 34.09)
]

cursor.executemany('INSERT INTO books VALUES (?, ?, ?, ?)', books_data)

conn.commit()
conn.close()
print("books.db created and filled successfully!")
