import sqlite3


conn = sqlite3.connect("bookstore.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    author TEXT,
    price REAL
)
""")

# Sample books
books_data = [
    ("Think Python", "Allen B. Downey", 475.0),
    ("Python Crash Course", "Eric Matthes", 650.0),
    ("Learning SQL", "Alan Beaulieu", 550.0),
    ("Automate the Boring Stuff", "Al Sweigart", 500.0)
]

# Insert only if table is empty
cursor.execute("SELECT COUNT(*) FROM books")
if cursor.fetchone()[0] == 0:
    cursor.executemany("INSERT INTO books (title, author, price) VALUES (?, ?, ?)", books_data)
    conn.commit()

# ---------- PART 2: Purchase process ----------
total_cost = 0

while True:
    title = input("\nBook Title: ").strip()

    cursor.execute("SELECT * FROM books WHERE title = ?", (title,))
    book = cursor.fetchone()

    if book:
        print(book)  # Shows: (id, title, author, price)
        qty = int(input("No. of copies: "))
        total_cost += qty * book[3]  # book[3] = price
    else:
        print("Book not found in the database.")

    more = input("Add more books? Y/N: ").strip().lower()
    if more != "y":
        break

print(f"\nTotal Cost: {total_cost}")
conn.close()
