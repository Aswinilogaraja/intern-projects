import tkinter as tk
from tkinter import messagebox

class CricketStatsApp:
    def __init__(self, root):
        self.root = root
        root.title("Cricket Player Stats")

        # Labels and Entry fields for each stat
        fields = [
            "Player Name", "Age", "Teams Played (comma separated)",
            "Formats (comma separated)", "Matches Played (format:value, comma separated)",
            "Batting Average", "Is Active (True/False)", "Career Span (start,end)",
            "Highest Score", "Awards (comma separated)"
        ]
        self.entries = {}

        for i, label in enumerate(fields):
            tk.Label(root, text=label+":").grid(row=i, column=0, sticky='e')
            entry = tk.Entry(root, width=40)
            entry.grid(row=i, column=1, padx=5, pady=2)
            self.entries[label] = entry

        # Submit Button
        tk.Button(root, text="Submit", command=self.process_input).grid(row=len(fields), column=0, columnspan=2, pady=10)

        # Output Text
        self.output = tk.Text(root, height=15, width=60)
        self.output.grid(row=len(fields)+1, column=0, columnspan=2, padx=5, pady=5)

    def process_input(self):
        try:
            player_name = self.entries["Player Name"].get().strip()
            age = int(self.entries["Age"].get().strip())
            teams_played = [team.strip() for team in self.entries["Teams Played (comma separated)"].get().split(",") if team.strip()]
            formats = tuple(fmt.strip() for fmt in self.entries["Formats (comma separated)"].get().split(",") if fmt.strip())

            # Parse matches_played
            matches_str = self.entries["Matches Played (format:value, comma separated)"].get()
            matches_played = {}
            for item in matches_str.split(","):
                if ":" in item:
                    fmt, val = item.split(":")
                    matches_played[fmt.strip()] = int(val.strip())

            batting_average = float(self.entries["Batting Average"].get().strip())
            is_active_str = self.entries["Is Active (True/False)"].get().strip().lower()
            is_active = (is_active_str == "true")

            career_span_str = self.entries["Career Span (start,end)"].get()
            start, end = [int(x.strip()) for x in career_span_str.split(",")]
            career_span = (start, end)

            highest_score = int(self.entries["Highest Score"].get().strip())
            awards = [award.strip() for award in self.entries["Awards (comma separated)"].get().split(",") if award.strip()]

            # Output area
            self.output.delete("1.0", tk.END)
            self.output.insert(tk.END, f"Player Name: {player_name}\n")
            self.output.insert(tk.END, f"Age: {age}\n")
            self.output.insert(tk.END, f"Teams Played: {teams_played}\n")
            self.output.insert(tk.END, f"Formats: {formats}\n")
            self.output.insert(tk.END, f"Matches Played: {matches_played}\n")
            self.output.insert(tk.END, f"Batting Average: {batting_average}\n")
            self.output.insert(tk.END, f"Is Active: {is_active}\n")
            self.output.insert(tk.END, f"Career Span: {career_span}\n")
            self.output.insert(tk.END, f"Highest Score: {highest_score}\n")
            self.output.insert(tk.END, f"Awards: {awards}\n")

        except Exception as e:
            messagebox.showerror("Error", f"Invalid input: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = CricketStatsApp(root)
    root.mainloop()
