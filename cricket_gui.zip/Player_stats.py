class CricketPlayer:
    def __init__(self, player_name, age, teams_played, formats, matches_played, batting_average,
                 is_active, career_span, highest_score, awards):
        self.player_name = player_name
        self.age = age
        self.teams_played = teams_played  # list
        self.formats = formats            # tuple
        self.matches_played = matches_played  # dict
        self.batting_average = batting_average
        self.is_active = is_active
        self.career_span = career_span    # tuple (start_year, end_year)
        self.highest_score = highest_score
        self.awards = awards              # list

    def career_length(self):
        return self.career_span[1] - self.career_span + 1

    def display_info(self):
        print(f"Player Name: {self.player_name}")
        print(f"Age: {self.age}")
        print(f"Teams played for: {', '.join(self.teams_played)}")
        print(f"Formats: {', '.join(self.formats)}")
        print("Matches played:")
        for fmt, count in self.matches_played.items():
            print(f"  {fmt}: {count}")
        print(f"Batting Average: {self.batting_average}")
        print(f"Active Player: {'Yes' if self.is_active else 'No'}")
        print(f"Career Span: {self.career_span} - {self.career_span[1]} ({self.career_length()} years)")
        print(f"Highest Score: {self.highest_score}")
        print(f"Awards: {', '.join(self.awards)}")

    def add_award(self, award_name):
        self.awards.append(award_name)
        print(f"Award '{award_name}' added.")

# Example usage
player = CricketPlayer(
    player_name="Virat Kohli",
    age=35,
    teams_played=["India", "RCB"],
    formats=("Test", "ODI", "T20"),
    matches_played={"Test": 111, "ODI": 275, "T20": 115},
    batting_average=53.6,
    is_active=True,
    career_span=(2008, 2025),
    highest_score=254,
    awards=["ICC Cricketer of the Year", "Padma Shri"]
)

player.display_info()
player.add_award("Rajiv Gandhi Khel Ratna")
